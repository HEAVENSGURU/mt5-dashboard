// components/Navbar.jsx
import React from 'react';
import { Link } from 'react-router-dom';
import useAuth from '../hooks/useAuth';

const Navbar = () => {
  const { isAuth, logout } = useAuth();

  return (
    <nav style={{ background: '#333', color: '#fff', padding: '1rem' }}>
      <span style={{ marginRight: '2rem' }}><strong>📊 MT5 Dashboard</strong></span>
      <Link to="/dashboard" style={{ marginRight: '1rem', color: '#fff' }}>Dashboard</Link>
      {!isAuth && (
        <>
          <Link to="/login" style={{ marginRight: '1rem', color: '#fff' }}>Login</Link>
          <Link to="/register" style={{ marginRight: '1rem', color: '#fff' }}>Register</Link>
        </>
      )}
      {isAuth && (
        <button onClick={logout} style={{ color: '#fff', background: 'red', border: 'none', padding: '0.5rem 1rem' }}>
          Logout
        </button>
      )}
    </nav>
  );
};

export default Navbar;