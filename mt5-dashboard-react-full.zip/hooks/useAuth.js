// hooks/useAuth.js
import { useEffect, useState } from 'react';
import jwtDecode from 'jwt-decode';

const useAuth = () => {
  const [isAuth, setIsAuth] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) return setIsAuth(false);
    try {
      const decoded = jwtDecode(token);
      const isExpired = decoded.exp * 1000 < Date.now();
      if (isExpired) {
        localStorage.removeItem('token');
        setIsAuth(false);
      } else {
        setIsAuth(true);
      }
    } catch {
      setIsAuth(false);
    }
  }, []);

  const logout = () => {
    localStorage.removeItem('token');
    setIsAuth(false);
  };

  return { isAuth, logout };
};

export default useAuth;